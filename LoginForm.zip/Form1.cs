﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace codechum
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void usernameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void passwordTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void usernamelabel_Click(object sender, EventArgs e)
        {

        }

        private void passwordlabel_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = usernameTextBox.Text;
            string password = passwordTextBox.Text;

            Dictionary<string, string> users = new Dictionary<string, string>()
    {
        {"admin", "admin12345" },
        {"user1", "password123" },
        {"student1", "PF101@2024" }
    };

            bool isValidLogin = false;
            foreach (KeyValuePair<string, string> pair in users)
            {
                if (pair.Key == username && pair.Value == password)
                {
                    isValidLogin = true;
                    break;
                }
            }

            // Display appropriate message based on login validity
            if (isValidLogin)
            {
                resultlabel.Text = "Login Successful";
            }
            else
            {
                resultlabel.Text = "Invalid username or password.";
            }
        }
        private void resultlabel_Click(object sender, EventArgs e)
        {

        }
    }
}
